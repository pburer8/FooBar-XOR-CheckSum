class Main {
	public static void main(String[] args) {
		//Initial conditions
		int start = 17;
		int length = 4;
		//Useful variables
		int checksum = 0;
		int count = 0;
		int length2 = length;

		//Takes decreasing sets of numbers  starting from start * (length + "row number"), row length is length - row number
		// 0 1 2 (start is 0, length is 3, "row number" is 0)
		// 3 4 / 
		// 6 / /
		while (length2!=0)
			{
				for (int i = 0; i<length2; i++)
					{
						int cs = (start+(length*count))+i;
						//Bitwise XOR, uh oh!
						checksum^=cs;
					}
				count++;
				length2--;
			}

		
		System.out.println(checksum);
	}
}